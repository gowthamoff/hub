
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'gowtham4929',
  applicationName: 'todo-serverless-api',
  appUid: 'hvbmcvrg2zfCBWMgnT',
  orgUid: '0e6912d4-7075-45fe-beb2-2dc58b367ffa',
  deploymentUid: '9cf3f9b5-e3a0-459c-bb69-6f4126aaa0b0',
  serviceName: 'todo-serverless-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'todo-serverless-api-dev-api', timeout: 7 };

try {
  const userHandler = require('./src/handler/todoHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}